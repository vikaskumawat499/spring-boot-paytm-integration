package mypack;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.CertStore;
import java.security.cert.Certificate;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.util.encoders.Base64;

public class pkcs7gen {
	public static void main(String args[]) throws Exception {
		String jks_file_path = null;
		String jks_file = null;
		String vendorID = null;
		String panCard = "AAAPW9785A";
		Properties prop = new Properties();
	    try {
	        prop.load(new FileInputStream("params.properties"));
	        jks_file_path=prop.getProperty("jks_file_path");
	        vendorID = prop.getProperty("vendorID");
	        
	    } catch (Exception e) {
	    }
	    String dataTsign = vendorID+"^"+panCard;
		String jks = GenrateJKS(jks_file_path,dataTsign);
		System.out.println(jks);
	}
	public static String GenrateJKS(String FilePath,String dataTsign) throws Exception {
		String signedData64String ="Error";
		KeyStore keystore = KeyStore.getInstance("jks");
		InputStream input = new FileInputStream(FilePath);
		try {
			char[] password = "password@123".toCharArray();
			keystore.load(input, password);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

		}
		Enumeration e ;
		e = keystore.aliases();
		String alias = "nsdl";

		if (e != null) {
			while (e.hasMoreElements()) {
				String n = (String) e.nextElement();
				if (keystore.isKeyEntry(n)) {
					alias = n;
				}
			}
		}
		PrivateKey privateKey = (PrivateKey) keystore.getKey(alias, "password@123".toCharArray());
		X509Certificate myPubCert = (X509Certificate) keystore.getCertificate(alias);
		byte[] dataToSign = dataTsign.getBytes();
		CMSSignedDataGenerator sgen = new CMSSignedDataGenerator();
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
//		System.out.println(privateKey + "**************************"+ myPubCert+ "---------"+ myPubCert.getVersion());
		sgen.addSigner(privateKey, myPubCert, CMSSignedDataGenerator.DIGEST_SHA1);
		Certificate[] certChain = keystore.getCertificateChain(alias);
		List certList = new ArrayList<String>();
		CertStore certs = null;
		for (int i = 0; i < certChain.length; i++)
			certList.add(certChain[i]);
		sgen.addCertificatesAndCRLs(
				CertStore.getInstance("Collection", new CollectionCertStoreParameters(certList), "BC"));
		CMSSignedData csd = sgen.generate(new CMSProcessableByteArray(dataToSign), true, "BC");
		byte[] signedData = csd.getEncoded();
		byte[] signedData64 = Base64.encode(signedData);
		signedData64String = new String(signedData64);
		return signedData64String;
	}
	
}
