package mypack;

import java.io.FileInputStream;
import java.util.Properties;

public class call {

	public static void main(String[] args) {
		String pan = "AAAPW9785A";
		String nsdString = NsdlAPICall(pan);
		System.out.println(nsdString);
	}
	public static String NsdlAPICall(String panCardNo) {

		String result = "Error";
		String jks = null;
		String jks_file_path = null;
		String vendorID = null;
		String nsdlURL = null;
		String panCard = panCardNo;
		try {

			Properties prop = new Properties();
			try {
				prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("params.properties"));
				jks_file_path = prop.getProperty("jks_file_path");
				vendorID = prop.getProperty("vendorID");
				nsdlURL= prop.getProperty("nsdlURL");
			} catch (Exception e) {
			}
			String dataTsign = vendorID + "^" + panCard;
			jks = pkcs7gen.GenrateJKS(jks_file_path , dataTsign);
//			System.err.println(jks);
			result = APIBased.APICallToNSDL(dataTsign, jks,nsdlURL);
//			System.err.println(result);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	
	}

}
