package mypack;

import java.io.IOException;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class nsdlAPIcall
 */
@WebServlet("/nsdlAPIcall")
public class nsdlAPIcall extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public nsdlAPIcall() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		String pan = "AAAPW9785A";
//		String nsdString = call.NsdlAPICall(pan);
//		System.out.println(nsdString);
//		response.getWriter().append("Served at: ").append(request.getContextPath()).append(nsdString);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String pan = request.getReader().lines().collect(Collectors.joining());
//		String pan = "AAAPW9785A";
		String nsdString = call.NsdlAPICall(pan);
		System.out.println(nsdString);
		response.getWriter().append(nsdString);
		
	}

}
